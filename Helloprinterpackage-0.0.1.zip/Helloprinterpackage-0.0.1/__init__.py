def add_word(word1, word2):
    return word1 + word2
Default_word = "Hello"
print(Default_word)